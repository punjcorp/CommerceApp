<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1530593492883" ID="ID_673100544" MODIFIED="1530594646260" TEXT="Register Open">
<hook NAME="accessories/plugins/RevisionPlugin.properties"/>
<node CREATED="1530593517444" ID="ID_511749171" MODIFIED="1530593759064" POSITION="right" TEXT="Is the Store in OPEN STATUS?">
<node CREATED="1530593529628" ID="ID_404112705" MODIFIED="1530593544673" TEXT="Yes, are there any valid registers?">
<node COLOR="#ff0000" CREATED="1530593592792" ID="ID_1400593258" MODIFIED="1530593656301" TEXT="No, show the error message and show option for register creation screen"/>
<node CREATED="1530593895469" ID="ID_14422680" MODIFIED="1530594359865" TEXT="Yes, Is selected register eligible for OPENING?">
<node CREATED="1530593941556" ID="ID_1218785881" MODIFIED="1530593965505" TEXT="Yes, Display the screen with current register select and with other controls visible"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1530593966445" ID="ID_1346912358" MODIFIED="1530595302026" TEXT="No, has the selected REGISTER already been OPENED for the day?">
<node BACKGROUND_COLOR="#ffff00" CREATED="1530595198813" ID="ID_1369783730" MODIFIED="1530595236275" TEXT="Yes, Proceed to transaction screen directly"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1530595252079" ID="ID_851838131" MODIFIED="1530595253802" TEXT="No, is there any other register eligible for OPENING in the STORE?">
<node CREATED="1530593990892" ID="ID_1802414820" MODIFIED="1530594008161" TEXT="Yes, retrieve all registers with last known status and display on screen for user selection">
<icon BUILTIN="full-1"/>
</node>
<node COLOR="#ff0000" CREATED="1530594009021" ID="ID_670885299" MODIFIED="1530594463977" TEXT="No, Display error and ask user to select any existing register for transactions">
<icon BUILTIN="full-2"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#ff0000" CREATED="1530593619805" ID="ID_1337719865" MODIFIED="1530593653940" TEXT="No, Display error and show option to reroute the user to store open screen"/>
</node>
<node CREATED="1530593665396" ID="ID_63947380" MODIFIED="1530594633469" POSITION="left" TEXT="Register selection Made.">
<icon BUILTIN="full-1"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="full-2"/>
<icon BUILTIN="button_ok"/>
<node CREATED="1530593698572" ID="ID_252221428" MODIFIED="1530594149177" TEXT="is register eligible for OPEN?">
<node COLOR="#338800" CREATED="1530593809452" ID="ID_651804467" MODIFIED="1530593875820" TEXT="Yes, Display the Conciliation Tender and denomination options with Open options"/>
<node COLOR="#ff0000" CREATED="1530593851812" ID="ID_520739707" MODIFIED="1530593873492" TEXT="No, show the error message and ask user to choose another register"/>
</node>
</node>
</node>
</map>
